# Simulador MIPS con Pipeline (en C)

Implementación de las 5 etapas del pipeline MIPS pedidas en el proyecto:

1. **Instruction Fetch + Program Counter** → `src/fetch.c` (`stage_fetch`)
2. **Instruction Decode** → `src/decode.c` (`stage_decode`)
3. **ALU** → `src/alu.c` (`stage_execute`)
4. **Memory** → `src/memory.c` (`stage_memory`)
5. **Write Back** → `src/writeback.c` (`stage_writeback`)

`src/pipeline.c` contiene `cpu_step()`, que es la función que **orquesta las 5
etapas** para procesar una instrucción, y las utilidades para inicializar la
CPU, cargar un programa y "ensamblar" instrucciones a mano (`encode_rtype`,
`encode_itype`, `encode_jtype`).

## Instrucciones soportadas
`add, sub, addi, and, or, nor, xor, lw, sw, beq, bne, j, jr`

## Cómo compilar y correr

```bash
make            # compila el simulador (./mips_sim)
make run        # compila y corre el programa de demostración (src/main.c)
make test       # compila y corre TODOS los unit tests + el test de sistema
make clean      # limpia binarios
```

## Estructura

```
include/mips.h        struct de la CPU, tipos de instrucción, prototipos de las 5 etapas
src/fetch.c            etapa 1
src/decode.c           etapa 2 (incluye la unidad de control)
src/alu.c              etapa 3
src/memory.c           etapa 4
src/writeback.c        etapa 5
src/pipeline.c          cpu_step() + utilidades (init, load, encoders)
src/main.c             programa de demostración
tests/test_fetch.c     unit test de la etapa 1
tests/test_decode.c    unit test de la etapa 2
tests/test_alu.c       unit test de la etapa 3
tests/test_memory.c    unit test de la etapa 4
tests/test_writeback.c unit test de la etapa 5
tests/test_system.c    test de sistema (integra las 5 etapas, vectores de prueba)
tests/test_utils.h     mini framework de pruebas (sin dependencias externas)
```

## ⚠️ Nota importante sobre el alcance actual

Esta versión ejecuta **una instrucción completa por ciclo** a través de las 5
etapas (fetch→decode→execute→memory→writeback), de forma secuencial. Esto es
funcionalmente correcto y es la base que la mayoría de los profesores
esperan para validar que las 5 funciones/etapas están bien implementadas.

Lo que **todavía NO implementa** (y es la extensión típica de "pipeline
real") es el **traslape de instrucciones**: que mientras una instrucción está
en Memory, la siguiente ya esté en ALU, la siguiente en Decode y la
siguiente en Fetch, todas al mismo tiempo. Para eso se necesitan:

- **Registros de pipeline** entre cada etapa (IF/ID, ID/EX, EX/MEM, MEM/WB)
  que retengan el estado de cada instrucción en tránsito.
- **Detección de riesgos de datos** (data hazards): p.ej. `add $t2,$t0,$t1`
  seguido de `sub $t3,$t2,$t0` necesita el valor de `$t2` antes de que haya
  terminado su Write Back → se resuelve con **forwarding/bypassing** o con
  **stalls** (burbujas).
- **Riesgos de control** (control hazards): qué hacer con las instrucciones
  ya cargadas cuando un `beq`/`bne`/`j`/`jr` sí se toma → se resuelve
  invalidando ("flush") las instrucciones incorrectas que ya entraron al
  pipeline.

Si tu profesor pide el pipeline con traslape real, el siguiente paso natural
es convertir `decoded_t`, `exec_result_t` y `mem_result_t` en **registros de
pipeline con validez (`valid` bit)** y llamar a las 5 funciones una vez por
etapa **por ciclo de reloj**, no una vez por instrucción. La lógica interna
de cada etapa (`stage_fetch`, `stage_decode`, etc.) prácticamente no cambia.

## Diagramas que pide "Parte 1"

Con este código ya puedes dibujar:
- **Diagrama del sistema**: 5 cajas (Fetch, Decode, ALU, Memory, WriteBack)
  conectadas en secuencia, con `cpu_state_t` (PC, regs[32], data_mem,
  instr_mem) como el estado compartido que cada etapa lee/escribe.
- **Diagrama de subfunciones**: dentro de Decode hay `parse_fields()` (separa
  bits) y `gen_control()` (decide señales); dentro de ALU hay
  `alu_compute()` (operación pura) y el cálculo de `branch_target` /
  `jump_target`.
