#ifndef MIPS_H
#define MIPS_H

#include <stdint.h>
#include <stddef.h>

#define NUM_REGS   32
#define MEM_SIZE   4096   /* bytes de memoria de datos */
#define IMEM_SIZE  1024   /* cantidad de instrucciones que caben en memoria de instrucciones */

/* ---------- Códigos de operación soportados ---------- */
typedef enum {
    OP_RTYPE = 0x00,
    OP_ADDI  = 0x08,
    OP_LW    = 0x23,
    OP_SW    = 0x2B,
    OP_BEQ   = 0x04,
    OP_BNE   = 0x05,
    OP_J     = 0x02
} opcode_t;

/* ---------- Códigos funct (solo para tipo R) ---------- */
typedef enum {
    FUNCT_ADD = 0x20,
    FUNCT_SUB = 0x22,
    FUNCT_AND = 0x24,
    FUNCT_OR  = 0x25,
    FUNCT_XOR = 0x26,
    FUNCT_NOR = 0x27,
    FUNCT_JR  = 0x08
} funct_t;

/* Instrucción de 32 bits ya separada en sus campos */
typedef struct {
    uint32_t raw;
    uint32_t opcode;
    uint32_t rs, rt, rd, shamt, funct;
    int32_t  imm;    /* immediate ya extendido en signo (para I-type) */
    uint32_t addr;   /* dirección de salto de 26 bits (para J-type) */
} instruction_t;

/* Señales de control que produce el Decode */
typedef struct {
    int reg_dst;     /* 1 = el registro destino es rd (R-type), 0 = rt (I-type) */
    int alu_src;      /* 1 = segundo operando de la ALU es el inmediato */
    int mem_to_reg;   /* 1 = el dato a escribir viene de memoria (lw) */
    int reg_write;    /* 1 = la instrucción escribe en el banco de registros */
    int mem_read;     /* 1 = lw */
    int mem_write;    /* 1 = sw */
    int branch;       /* 1 = beq */
    int branch_ne;    /* 1 = bne */
    int jump;         /* 1 = j  */
    int jr;           /* 1 = jr */
    int alu_op;       /* qué operación debe hacer la ALU (ver alu_op_t) */
} control_t;

typedef enum {
    ALU_ADD, ALU_SUB, ALU_AND, ALU_OR, ALU_XOR, ALU_NOR, ALU_NOP
} alu_op_t;

/* Salida combinada del Fetch+Decode: esto es lo que viaja al Execute */
typedef struct {
    instruction_t instr;
    control_t ctrl;
    int32_t val_rs;    /* valor leído del banco de registros para rs */
    int32_t val_rt;    /* valor leído del banco de registros para rt */
    uint32_t pc_next;  /* PC + 4, útil para calcular saltos/branches */
} decoded_t;

/* Salida del Execute (ALU) */
typedef struct {
    int32_t  alu_result;
    int      zero;            /* 1 si alu_result == 0 (para branches) */
    uint32_t branch_target;   /* PC destino si el branch se toma */
    uint32_t jump_target;     /* PC destino si es un jump */
} exec_result_t;

/* Salida del Memory */
typedef struct {
    int32_t mem_data;    /* dato leído de memoria (lw) */
    int32_t alu_result;  /* se re-propaga para el Write Back */
} mem_result_t;

/* Estado completo de la máquina (registros, memorias, PC) */
typedef struct {
    int32_t  regs[NUM_REGS];
    uint8_t  data_mem[MEM_SIZE];
    uint32_t instr_mem[IMEM_SIZE];
    uint32_t pc;
    int      running;
    int      num_instructions;
} cpu_state_t;

/* ---------------- Las 5 funciones de etapa ---------------- */

/* 1. Instruction Fetch + Program Counter */
uint32_t stage_fetch(cpu_state_t *cpu);

/* 2. Instruction Decode (separa campos, genera señales de control, lee regs) */
decoded_t stage_decode(cpu_state_t *cpu, uint32_t raw);

/* 3. ALU (ejecuta la operación aritmética/lógica, calcula branch target) */
exec_result_t stage_execute(decoded_t d);

/* 4. Memory (acceso a memoria de datos para lw / sw) */
mem_result_t stage_memory(cpu_state_t *cpu, decoded_t d, exec_result_t ex);

/* 5. Write Back (escribe el resultado final en el banco de registros) */
void stage_writeback(cpu_state_t *cpu, decoded_t d, mem_result_t mr);

/* Orquesta las 5 etapas para UNA instrucción (ciclo completo, sin traslape).
 * Devuelve 0 si no hay más instrucciones que ejecutar. */
int cpu_step(cpu_state_t *cpu);

/* ---------------- Utilidades ---------------- */
void cpu_init(cpu_state_t *cpu);
void cpu_load_program(cpu_state_t *cpu, const uint32_t *program, size_t n);
void cpu_run(cpu_state_t *cpu, int max_cycles);

/* Helpers para ensamblar instrucciones a mano en las pruebas / main.c */
uint32_t encode_rtype(uint32_t opcode, uint32_t rs, uint32_t rt, uint32_t rd, uint32_t shamt, uint32_t funct);
uint32_t encode_itype(uint32_t opcode, uint32_t rs, uint32_t rt, int32_t imm);
uint32_t encode_jtype(uint32_t opcode, uint32_t addr);

#endif /* MIPS_H */
