#include "mips.h"

/* Subfunción: la ALU pura, dado 2 operandos y una operación devuelve el resultado */
static int32_t alu_compute(int32_t a, int32_t b, alu_op_t op) {
    switch (op) {
        case ALU_ADD: return a + b;
        case ALU_SUB: return a - b;
        case ALU_AND: return a & b;
        case ALU_OR:  return a | b;
        case ALU_XOR: return a ^ b;
        case ALU_NOR: return ~(a | b);
        default:      return 0;
    }
}

/*
 * Etapa 3: ALU
 * - Selecciona el segundo operando (registro o inmediato) según alu_src
 * - Calcula el resultado de la ALU
 * - Calcula la dirección destino del branch (PC+4 + imm*4) y del jump
 */
exec_result_t stage_execute(decoded_t d) {
    exec_result_t ex = {0};

    int32_t operand_b = d.ctrl.alu_src ? d.instr.imm : d.val_rt;

    ex.alu_result = alu_compute(d.val_rs, operand_b, (alu_op_t)d.ctrl.alu_op);
    ex.zero = (ex.alu_result == 0);

    ex.branch_target = d.pc_next + ((uint32_t)(d.instr.imm) << 2);

    /* dirección de jump: 4 bits altos del PC + addr(26 bits) desplazado 2 */
    ex.jump_target = (d.pc_next & 0xF0000000) | (d.instr.addr << 2);

    return ex;
}
