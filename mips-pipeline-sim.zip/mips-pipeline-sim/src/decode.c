#include "mips.h"

/* Subfunción: separa los campos crudos de una instrucción de 32 bits */
static instruction_t parse_fields(uint32_t raw) {
    instruction_t ins;
    ins.raw    = raw;
    ins.opcode = (raw >> 26) & 0x3F;
    ins.rs     = (raw >> 21) & 0x1F;
    ins.rt     = (raw >> 16) & 0x1F;
    ins.rd     = (raw >> 11) & 0x1F;
    ins.shamt  = (raw >> 6)  & 0x1F;
    ins.funct  = raw & 0x3F;

    /* immediate de 16 bits, extendido en signo a 32 bits */
    int16_t imm16 = (int16_t)(raw & 0xFFFF);
    ins.imm = (int32_t)imm16;

    /* dirección de 26 bits para j */
    ins.addr = raw & 0x03FFFFFF;

    return ins;
}

/* Subfunción: unidad de control. Dado opcode/funct decide las señales */
static control_t gen_control(instruction_t ins) {
    control_t c = {0};

    switch (ins.opcode) {
        case OP_RTYPE:
            c.reg_dst = 1;
            c.reg_write = 1;
            switch (ins.funct) {
                case FUNCT_ADD: c.alu_op = ALU_ADD; break;
                case FUNCT_SUB: c.alu_op = ALU_SUB; break;
                case FUNCT_AND: c.alu_op = ALU_AND; break;
                case FUNCT_OR:  c.alu_op = ALU_OR;  break;
                case FUNCT_XOR: c.alu_op = ALU_XOR; break;
                case FUNCT_NOR: c.alu_op = ALU_NOR; break;
                case FUNCT_JR:
                    c.jr = 1;
                    c.reg_write = 0;
                    c.reg_dst = 0;
                    break;
                default: break;
            }
            break;

        case OP_ADDI:
            c.alu_src = 1;
            c.reg_write = 1;
            c.alu_op = ALU_ADD;
            break;

        case OP_LW:
            c.alu_src = 1;
            c.mem_read = 1;
            c.mem_to_reg = 1;
            c.reg_write = 1;
            c.alu_op = ALU_ADD;
            break;

        case OP_SW:
            c.alu_src = 1;
            c.mem_write = 1;
            c.alu_op = ALU_ADD;
            break;

        case OP_BEQ:
            c.branch = 1;
            c.alu_op = ALU_SUB;
            break;

        case OP_BNE:
            c.branch_ne = 1;
            c.alu_op = ALU_SUB;
            break;

        case OP_J:
            c.jump = 1;
            break;

        default:
            break;
    }
    return c;
}

/*
 * Etapa 2: Instruction Decode
 * - Separa los campos de la instrucción
 * - Genera las señales de control
 * - Lee del banco de registros los valores de rs y rt
 */
decoded_t stage_decode(cpu_state_t *cpu, uint32_t raw) {
    decoded_t d;
    d.instr = parse_fields(raw);
    d.ctrl  = gen_control(d.instr);
    d.val_rs = cpu->regs[d.instr.rs];
    d.val_rt = cpu->regs[d.instr.rt];
    d.pc_next = cpu->pc; /* stage_fetch ya incrementó cpu->pc en 4 */
    return d;
}
