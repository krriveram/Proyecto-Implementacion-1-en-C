#include "mips.h"

/*
 * Etapa 1: Instruction Fetch + Program Counter
 * - Lee la instrucción apuntada por PC desde instr_mem
 * - Incrementa PC en 4 (siguiente instrucción)
 * - Si PC se sale de la memoria de instrucciones, marca cpu->running = 0
 */
uint32_t stage_fetch(cpu_state_t *cpu) {
    uint32_t idx = cpu->pc / 4;
    uint32_t raw = 0;

    if (idx < IMEM_SIZE && idx < (uint32_t)cpu->num_instructions) {
        raw = cpu->instr_mem[idx];
    } else {
        cpu->running = 0;
        return 0;
    }

    cpu->pc += 4;
    return raw;
}
