#include <stdio.h>
#include "mips.h"

/*
 * Programa de demostración (equivalente en MIPS assembly):
 *
 *   addi $t0, $zero, 5      # $t0 = 5
 *   addi $t1, $zero, 7      # $t1 = 7
 *   add  $t2, $t0, $t1      # $t2 = $t0 + $t1        -> 12
 *   sub  $t3, $t1, $t0      # $t3 = $t1 - $t0        -> 2
 *   sw   $t2, 0($zero)      # mem[0] = $t2
 *   lw   $t4, 0($zero)      # $t4 = mem[0]           -> 12
 *   beq  $t2, $t4, +1       # se toma (12 == 12), salta 1 instrucción
 *   addi $t5, $zero, 99     # (se salta, no se ejecuta)
 *   addi $t6, $zero, 1      # $t6 = 1
 *
 * Registros usados: $t0=8, $t1=9, $t2=10, $t3=11, $t4=12, $t5=13, $t6=14
 */
int main(void) {
    uint32_t program[] = {
        encode_itype(OP_ADDI, 0, 8, 5),
        encode_itype(OP_ADDI, 0, 9, 7),
        encode_rtype(OP_RTYPE, 8, 9, 10, 0, FUNCT_ADD),
        encode_rtype(OP_RTYPE, 9, 8, 11, 0, FUNCT_SUB),
        encode_itype(OP_SW, 0, 10, 0),
        encode_itype(OP_LW, 0, 12, 0),
        encode_itype(OP_BEQ, 10, 12, 1),
        encode_itype(OP_ADDI, 0, 13, 99),
        encode_itype(OP_ADDI, 0, 14, 1),
    };

    cpu_state_t cpu;
    cpu_init(&cpu);
    cpu_load_program(&cpu, program, sizeof(program) / sizeof(program[0]));
    cpu_run(&cpu, 100);

    printf("=== Estado final de registros ===\n");
    printf("$t0 = %d\n", cpu.regs[8]);
    printf("$t1 = %d\n", cpu.regs[9]);
    printf("$t2 = %d\n", cpu.regs[10]);
    printf("$t3 = %d\n", cpu.regs[11]);
    printf("$t4 = %d\n", cpu.regs[12]);
    printf("$t5 = %d (debería quedar en 0, la instruccion se salto)\n", cpu.regs[13]);
    printf("$t6 = %d\n", cpu.regs[14]);

    return 0;
}
