#include "mips.h"
#include <string.h>

/*
 * Etapa 4: Memory
 * - Si mem_write (sw): escribe val_rt en data_mem[alu_result]
 * - Si mem_read (lw): lee una palabra de 32 bits de data_mem[alu_result]
 * - Siempre re-propaga alu_result para que write back lo pueda usar en R-type/addi
 *
 * Memoria "byte-addressable" pero solo soportamos acceso alineado a palabra (4 bytes),
 * como en MIPS real.
 */
mem_result_t stage_memory(cpu_state_t *cpu, decoded_t d, exec_result_t ex) {
    mem_result_t mr = {0};
    mr.alu_result = ex.alu_result;

    uint32_t addr = (uint32_t)ex.alu_result;

    if (d.ctrl.mem_write) {
        if (addr + 4 <= MEM_SIZE) {
            memcpy(&cpu->data_mem[addr], &d.val_rt, sizeof(int32_t));
        }
    }

    if (d.ctrl.mem_read) {
        int32_t value = 0;
        if (addr + 4 <= MEM_SIZE) {
            memcpy(&value, &cpu->data_mem[addr], sizeof(int32_t));
        }
        mr.mem_data = value;
    }

    return mr;
}
