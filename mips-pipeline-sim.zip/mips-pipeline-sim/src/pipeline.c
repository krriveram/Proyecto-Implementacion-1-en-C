#include "mips.h"
#include <string.h>

void cpu_init(cpu_state_t *cpu) {
    memset(cpu, 0, sizeof(cpu_state_t));
    cpu->pc = 0;
    cpu->running = 1;
    cpu->num_instructions = 0;
}

void cpu_load_program(cpu_state_t *cpu, const uint32_t *program, size_t n) {
    for (size_t i = 0; i < n && i < IMEM_SIZE; i++) {
        cpu->instr_mem[i] = program[i];
    }
    cpu->num_instructions = (int)n;
    cpu->pc = 0;
    cpu->running = 1;
}

/*
 * cpu_step: ejecuta UNA instrucción completa a través de las 5 etapas.
 *
 * NOTA IMPORTANTE (léase el README): esta versión ejecuta las etapas de forma
 * secuencial para una sola instrucción por llamada (no hay traslape real de
 * instrucciones ni riesgos de datos/control que resolver). Esto corresponde
 * a la funcionalidad "single-cycle" que sirve de base correcta antes de
 * agregar el traslape (pipeline real) con hazard detection, forwarding y
 * stalls, que es la extensión natural de este proyecto.
 */
int cpu_step(cpu_state_t *cpu) {
    if (!cpu->running) return 0;

    uint32_t raw = stage_fetch(cpu);
    if (!cpu->running) return 0; /* stage_fetch se quedó sin instrucciones */

    decoded_t d   = stage_decode(cpu, raw);
    exec_result_t ex = stage_execute(d);
    mem_result_t  mr  = stage_memory(cpu, d, ex);
    stage_writeback(cpu, d, mr);

    /* Resolución de saltos y branches: se actualiza PC al final del ciclo */
    if (d.ctrl.jump) {
        cpu->pc = ex.jump_target;
    } else if (d.ctrl.jr) {
        cpu->pc = (uint32_t)d.val_rs;
    } else if (d.ctrl.branch && ex.zero) {
        cpu->pc = ex.branch_target;
    } else if (d.ctrl.branch_ne && !ex.zero) {
        cpu->pc = ex.branch_target;
    }

    return 1;
}

void cpu_run(cpu_state_t *cpu, int max_cycles) {
    int cycles = 0;
    while (cpu->running && cycles < max_cycles) {
        if (!cpu_step(cpu)) break;
        cycles++;
    }
}

/* ---------------- Encoders: para armar instrucciones a mano en tests/main ---------------- */

uint32_t encode_rtype(uint32_t opcode, uint32_t rs, uint32_t rt, uint32_t rd, uint32_t shamt, uint32_t funct) {
    return (opcode << 26) | ((rs & 0x1F) << 21) | ((rt & 0x1F) << 16) |
           ((rd & 0x1F) << 11) | ((shamt & 0x1F) << 6) | (funct & 0x3F);
}

uint32_t encode_itype(uint32_t opcode, uint32_t rs, uint32_t rt, int32_t imm) {
    return (opcode << 26) | ((rs & 0x1F) << 21) | ((rt & 0x1F) << 16) | (imm & 0xFFFF);
}

uint32_t encode_jtype(uint32_t opcode, uint32_t addr) {
    return (opcode << 26) | (addr & 0x03FFFFFF);
}
