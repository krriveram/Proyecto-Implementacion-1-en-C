#include "mips.h"

/*
 * Etapa 5: Write Back
 * - Decide el registro destino (rd para R-type, rt para I-type) según reg_dst
 * - Decide el dato a escribir (memoria si mem_to_reg, si no el resultado de la ALU)
 * - Nunca escribe en $zero (registro 0), igual que el hardware real de MIPS
 */
void stage_writeback(cpu_state_t *cpu, decoded_t d, mem_result_t mr) {
    if (!d.ctrl.reg_write) return;

    uint32_t dest_reg = d.ctrl.reg_dst ? d.instr.rd : d.instr.rt;
    if (dest_reg == 0) return; /* $zero siempre es 0 */

    int32_t value = d.ctrl.mem_to_reg ? mr.mem_data : mr.alu_result;
    cpu->regs[dest_reg] = value;
}
