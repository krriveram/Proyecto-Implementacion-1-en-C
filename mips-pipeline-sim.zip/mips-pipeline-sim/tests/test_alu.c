#include "mips.h"
#include "test_utils.h"

static decoded_t make_decoded(int32_t a, int32_t b, alu_op_t op, int alu_src) {
    decoded_t d = {0};
    d.val_rs = a;
    d.val_rt = b;
    d.ctrl.alu_op = op;
    d.ctrl.alu_src = alu_src;
    d.instr.imm = b; /* si alu_src=1, b actua como el inmediato */
    return d;
}

int main(void) {
    TEST_SECTION("stage_execute: operaciones aritmeticas y logicas");

    exec_result_t r;

    r = stage_execute(make_decoded(5, 3, ALU_ADD, 0));
    TEST_ASSERT_EQ("add: 5 + 3 = 8", r.alu_result, 8);

    r = stage_execute(make_decoded(5, 3, ALU_SUB, 0));
    TEST_ASSERT_EQ("sub: 5 - 3 = 2", r.alu_result, 2);

    r = stage_execute(make_decoded(5, 5, ALU_SUB, 0));
    TEST_ASSERT_EQ("sub igual a cero activa zero flag", r.zero, 1);

    r = stage_execute(make_decoded(0xF0, 0x0F, ALU_AND, 0));
    TEST_ASSERT_EQ("and bit a bit", r.alu_result, 0x00);

    r = stage_execute(make_decoded(0xF0, 0x0F, ALU_OR, 0));
    TEST_ASSERT_EQ("or bit a bit", r.alu_result, 0xFF);

    r = stage_execute(make_decoded(0xFF, 0x0F, ALU_XOR, 0));
    TEST_ASSERT_EQ("xor bit a bit", r.alu_result, 0xF0);

    r = stage_execute(make_decoded(0, 0, ALU_NOR, 0));
    TEST_ASSERT_EQ("nor de 0,0 es todo unos (-1 en complemento a 2)", r.alu_result, -1);

    TEST_SECTION("stage_execute: alu_src selecciona inmediato vs registro");
    r = stage_execute(make_decoded(10, 4, ALU_ADD, 1)); /* usa imm=4 en vez de val_rt */
    TEST_ASSERT_EQ("addi usa el inmediato como segundo operando", r.alu_result, 14);

    TEST_SECTION("stage_execute: calculo de direcciones de branch y jump");
    decoded_t d = {0};
    d.pc_next = 100;
    d.instr.imm = 2; /* offset de 2 instrucciones */
    r = stage_execute(d);
    TEST_ASSERT_EQ("branch target = pc_next + imm*4", r.branch_target, 108);

    decoded_t dj = {0};
    dj.pc_next = 0x00001000;
    dj.instr.addr = 0x10;
    r = stage_execute(dj);
    TEST_ASSERT_EQ("jump target = bits altos de pc_next + addr<<2", r.jump_target, 0x40);

    TEST_SUMMARY();
}
