#include "mips.h"
#include "test_utils.h"

int main(void) {
    TEST_SECTION("stage_decode: campos e instrucciones tipo R");

    cpu_state_t cpu;
    cpu_init(&cpu);
    cpu.regs[8] = 10;  /* $t0 */
    cpu.regs[9] = 20;  /* $t1 */

    uint32_t raw_add = encode_rtype(OP_RTYPE, 8, 9, 10, 0, FUNCT_ADD);
    decoded_t d = stage_decode(&cpu, raw_add);

    TEST_ASSERT_EQ("opcode de add es 0", d.instr.opcode, 0);
    TEST_ASSERT_EQ("rs = 8", d.instr.rs, 8);
    TEST_ASSERT_EQ("rt = 9", d.instr.rt, 9);
    TEST_ASSERT_EQ("rd = 10", d.instr.rd, 10);
    TEST_ASSERT_EQ("funct = FUNCT_ADD", d.instr.funct, FUNCT_ADD);
    TEST_ASSERT_EQ("val_rs leido del regfile", d.val_rs, 10);
    TEST_ASSERT_EQ("val_rt leido del regfile", d.val_rt, 20);
    TEST_ASSERT_EQ("reg_write activo para add", d.ctrl.reg_write, 1);
    TEST_ASSERT_EQ("reg_dst activo (usa rd) para add", d.ctrl.reg_dst, 1);
    TEST_ASSERT_EQ("alu_src apagado (usa registro, no inmediato)", d.ctrl.alu_src, 0);
    TEST_ASSERT_EQ("alu_op = ALU_ADD", d.ctrl.alu_op, ALU_ADD);

    TEST_SECTION("stage_decode: instrucciones tipo I (addi, lw, sw, beq)");

    uint32_t raw_addi = encode_itype(OP_ADDI, 8, 9, -3);
    decoded_t d_addi = stage_decode(&cpu, raw_addi);
    TEST_ASSERT_EQ("addi: immediate con signo extendido correctamente", d_addi.instr.imm, -3);
    TEST_ASSERT_EQ("addi: alu_src activo (usa inmediato)", d_addi.ctrl.alu_src, 1);
    TEST_ASSERT_EQ("addi: reg_dst apagado (destino es rt)", d_addi.ctrl.reg_dst, 0);

    uint32_t raw_lw = encode_itype(OP_LW, 8, 9, 4);
    decoded_t d_lw = stage_decode(&cpu, raw_lw);
    TEST_ASSERT_EQ("lw: mem_read activo", d_lw.ctrl.mem_read, 1);
    TEST_ASSERT_EQ("lw: mem_to_reg activo", d_lw.ctrl.mem_to_reg, 1);

    uint32_t raw_sw = encode_itype(OP_SW, 8, 9, 4);
    decoded_t d_sw = stage_decode(&cpu, raw_sw);
    TEST_ASSERT_EQ("sw: mem_write activo", d_sw.ctrl.mem_write, 1);
    TEST_ASSERT_EQ("sw: reg_write apagado (no escribe registro)", d_sw.ctrl.reg_write, 0);

    uint32_t raw_beq = encode_itype(OP_BEQ, 8, 9, 2);
    decoded_t d_beq = stage_decode(&cpu, raw_beq);
    TEST_ASSERT_EQ("beq: branch activo", d_beq.ctrl.branch, 1);

    TEST_SECTION("stage_decode: instruccion tipo J (j, jr)");

    uint32_t raw_j = encode_jtype(OP_J, 0x123);
    decoded_t d_j = stage_decode(&cpu, raw_j);
    TEST_ASSERT_EQ("j: jump activo", d_j.ctrl.jump, 1);
    TEST_ASSERT_EQ("j: direccion decodificada correctamente", d_j.instr.addr, 0x123);

    uint32_t raw_jr = encode_rtype(OP_RTYPE, 8, 0, 0, 0, FUNCT_JR);
    decoded_t d_jr = stage_decode(&cpu, raw_jr);
    TEST_ASSERT_EQ("jr: señal jr activa", d_jr.ctrl.jr, 1);
    TEST_ASSERT_EQ("jr: no escribe registro", d_jr.ctrl.reg_write, 0);

    TEST_SUMMARY();
}
