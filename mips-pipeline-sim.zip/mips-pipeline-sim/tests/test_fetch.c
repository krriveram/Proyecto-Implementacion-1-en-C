#include "mips.h"
#include "test_utils.h"

int main(void) {
    TEST_SECTION("stage_fetch");

    cpu_state_t cpu;
    uint32_t program[] = { 0x11111111, 0x22222222, 0x33333333 };
    cpu_init(&cpu);
    cpu_load_program(&cpu, program, 3);

    uint32_t i0 = stage_fetch(&cpu);
    TEST_ASSERT_EQ("primera instruccion leida correctamente", i0, 0x11111111);
    TEST_ASSERT_EQ("PC avanza a 4 tras el primer fetch", cpu.pc, 4);

    uint32_t i1 = stage_fetch(&cpu);
    TEST_ASSERT_EQ("segunda instruccion leida correctamente", i1, 0x22222222);
    TEST_ASSERT_EQ("PC avanza a 8 tras el segundo fetch", cpu.pc, 8);

    stage_fetch(&cpu); /* consume la 3ra y ultima instruccion */
    TEST_ASSERT_EQ("cpu sigue corriendo mientras haya instrucciones", cpu.running, 1);

    stage_fetch(&cpu); /* ya no hay mas instrucciones */
    TEST_ASSERT_EQ("cpu se detiene al acabarse el programa", cpu.running, 0);

    TEST_SUMMARY();
}
