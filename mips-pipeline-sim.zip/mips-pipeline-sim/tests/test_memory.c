#include "mips.h"
#include "test_utils.h"

int main(void) {
    TEST_SECTION("stage_memory: sw (escritura)");

    cpu_state_t cpu;
    cpu_init(&cpu);

    decoded_t d_sw = {0};
    d_sw.ctrl.mem_write = 1;
    d_sw.val_rt = 42; /* valor a guardar */
    exec_result_t ex_sw = {0};
    ex_sw.alu_result = 8; /* direccion */

    stage_memory(&cpu, d_sw, ex_sw);

    int32_t stored;
    __builtin_memcpy(&stored, &cpu.data_mem[8], sizeof(int32_t));
    TEST_ASSERT_EQ("sw escribe el valor correcto en la direccion", stored, 42);

    TEST_SECTION("stage_memory: lw (lectura)");

    decoded_t d_lw = {0};
    d_lw.ctrl.mem_read = 1;
    exec_result_t ex_lw = {0};
    ex_lw.alu_result = 8; /* misma direccion que escribimos arriba */

    mem_result_t mr = stage_memory(&cpu, d_lw, ex_lw);
    TEST_ASSERT_EQ("lw lee el valor previamente escrito", mr.mem_data, 42);

    TEST_SECTION("stage_memory: instrucciones que no tocan memoria (add) propagan alu_result");
    decoded_t d_add = {0};
    exec_result_t ex_add = {0};
    ex_add.alu_result = 99;
    mem_result_t mr_add = stage_memory(&cpu, d_add, ex_add);
    TEST_ASSERT_EQ("alu_result se re-propaga sin tocar memoria", mr_add.alu_result, 99);

    TEST_SUMMARY();
}
