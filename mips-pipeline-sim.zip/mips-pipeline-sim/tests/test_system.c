#include "mips.h"
#include "test_utils.h"

/* Vector de prueba 1: aritmetica + logica basica */
static void test_aritmetica_logica(void) {
    TEST_SECTION("Sistema: aritmetica y logica (add, sub, and, or, xor, nor, addi)");

    uint32_t program[] = {
        encode_itype(OP_ADDI, 0, 8, 12),                 /* $t0 = 12 */
        encode_itype(OP_ADDI, 0, 9, 5),                  /* $t1 = 5  */
        encode_rtype(OP_RTYPE, 8, 9, 10, 0, FUNCT_ADD),  /* $t2 = $t0+$t1 = 17 */
        encode_rtype(OP_RTYPE, 8, 9, 11, 0, FUNCT_SUB),  /* $t3 = $t0-$t1 = 7  */
        encode_rtype(OP_RTYPE, 8, 9, 12, 0, FUNCT_AND),  /* $t4 = $t0&$t1      */
        encode_rtype(OP_RTYPE, 8, 9, 13, 0, FUNCT_OR),   /* $t5 = $t0|$t1      */
        encode_rtype(OP_RTYPE, 8, 9, 14, 0, FUNCT_XOR),  /* $t6 = $t0^$t1      */
        encode_rtype(OP_RTYPE, 8, 9, 15, 0, FUNCT_NOR),  /* $t7 = ~($t0|$t1)   */
    };

    cpu_state_t cpu;
    cpu_init(&cpu);
    cpu_load_program(&cpu, program, sizeof(program) / sizeof(program[0]));
    cpu_run(&cpu, 100);

    TEST_ASSERT_EQ("$t2 = 12 + 5", cpu.regs[10], 17);
    TEST_ASSERT_EQ("$t3 = 12 - 5", cpu.regs[11], 7);
    TEST_ASSERT_EQ("$t4 = 12 & 5", cpu.regs[12], (12 & 5));
    TEST_ASSERT_EQ("$t5 = 12 | 5", cpu.regs[13], (12 | 5));
    TEST_ASSERT_EQ("$t6 = 12 ^ 5", cpu.regs[14], (12 ^ 5));
    TEST_ASSERT_EQ("$t7 = ~(12 | 5)", cpu.regs[15], ~(12 | 5));
}

/* Vector de prueba 2: memoria (lw/sw) */
static void test_memoria(void) {
    TEST_SECTION("Sistema: memoria (lw, sw)");

    uint32_t program[] = {
        encode_itype(OP_ADDI, 0, 8, 1234),  /* $t0 = 1234 */
        encode_itype(OP_SW, 0, 8, 20),      /* mem[20] = $t0 */
        encode_itype(OP_LW, 0, 9, 20),      /* $t1 = mem[20] */
    };

    cpu_state_t cpu;
    cpu_init(&cpu);
    cpu_load_program(&cpu, program, sizeof(program) / sizeof(program[0]));
    cpu_run(&cpu, 100);

    TEST_ASSERT_EQ("lw recupera lo que sw guardo", cpu.regs[9], 1234);
}

/* Vector de prueba 3: branches (beq, bne) */
static void test_branches(void) {
    TEST_SECTION("Sistema: branches (beq, bne)");

    uint32_t program[] = {
        encode_itype(OP_ADDI, 0, 8, 5),     /* 0: $t0 = 5 */
        encode_itype(OP_ADDI, 0, 9, 5),     /* 1: $t1 = 5 */
        encode_itype(OP_BEQ, 8, 9, 1),      /* 2: si $t0==$t1 salta 1 -> a la 4 */
        encode_itype(OP_ADDI, 0, 10, 111),  /* 3: (se salta, NO se ejecuta) */
        encode_itype(OP_ADDI, 0, 11, 222),  /* 4: $t3 = 222 */
        encode_itype(OP_BNE, 8, 9, 1),      /* 5: $t0==$t1, bne NO salta */
        encode_itype(OP_ADDI, 0, 12, 333),  /* 6: $t4 = 333 (SI se ejecuta) */
    };

    cpu_state_t cpu;
    cpu_init(&cpu);
    cpu_load_program(&cpu, program, sizeof(program) / sizeof(program[0]));
    cpu_run(&cpu, 100);

    TEST_ASSERT_EQ("beq tomado: la instruccion saltada no se ejecuta", cpu.regs[10], 0);
    TEST_ASSERT_EQ("beq tomado: la instruccion despues del salto si corre", cpu.regs[11], 222);
    TEST_ASSERT_EQ("bne no tomado (iguales): la siguiente instruccion corre normal", cpu.regs[12], 333);
}

/* Vector de prueba 4: j y jr
 * OJO: en MIPS real, jr salta a la DIRECCION EN BYTES que trae el registro
 * (no a un "indice de instruccion"), por eso $t1 se carga con addr_en_bytes = indice*4.
 */
static void test_saltos(void) {
    TEST_SECTION("Sistema: saltos incondicionales (j, jr)");

    uint32_t program[] = {
        encode_jtype(OP_J, 3),               /* 0 (byte 0):  salta directo a instr. 3 */
        encode_itype(OP_ADDI, 0, 8, 111),    /* 1 (byte 4):  (se salta por el j) */
        encode_itype(OP_ADDI, 0, 8, 222),    /* 2 (byte 8):  (se salta por el j) */
        encode_itype(OP_ADDI, 0, 9, 24),     /* 3 (byte 12): $t1 = 24 (direccion en bytes de la instr. 6) */
        encode_rtype(OP_RTYPE, 9, 0, 0, 0, FUNCT_JR), /* 4 (byte 16): jr $t1 -> PC = 24 */
        encode_itype(OP_ADDI, 0, 10, 999),   /* 5 (byte 20): (se salta por el jr) */
        encode_itype(OP_ADDI, 0, 11, 4),     /* 6 (byte 24): destino del jr, si corre */
    };

    cpu_state_t cpu;
    cpu_init(&cpu);
    cpu_load_program(&cpu, program, sizeof(program) / sizeof(program[0]));
    cpu_run(&cpu, 100);

    TEST_ASSERT_EQ("j salta y las instrucciones intermedias no corren ($t0)", cpu.regs[8], 0);
    TEST_ASSERT_EQ("jr salta y se brinca la instruccion intermedia ($t2)", cpu.regs[10], 0);
    TEST_ASSERT_EQ("la instruccion destino de jr si corre ($t3=4)", cpu.regs[11], 4);
}

int main(void) {
    test_aritmetica_logica();
    test_memoria();
    test_branches();
    test_saltos();
    TEST_SUMMARY();
}
