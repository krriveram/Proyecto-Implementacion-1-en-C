#ifndef TEST_UTILS_H
#define TEST_UTILS_H

#include <stdio.h>

static int tests_run = 0;
static int tests_failed = 0;

#define TEST_ASSERT_EQ(desc, actual, expected) do { \
    tests_run++; \
    long a_ = (long)(actual); \
    long e_ = (long)(expected); \
    if (a_ != e_) { \
        tests_failed++; \
        printf("  [FAIL] %s (esperado=%ld, obtenido=%ld)\n", desc, e_, a_); \
    } else { \
        printf("  [OK]   %s\n", desc); \
    } \
} while (0)

#define TEST_SECTION(name) printf("\n-- %s --\n", name)

#define TEST_SUMMARY() do { \
    printf("\n%d/%d pruebas pasaron.\n", tests_run - tests_failed, tests_run); \
    if (tests_failed > 0) { \
        printf("HAY %d PRUEBA(S) FALLIDA(S)\n", tests_failed); \
        return 1; \
    } \
    return 0; \
} while (0)

#endif
