#include "mips.h"
#include "test_utils.h"

int main(void) {
    TEST_SECTION("stage_writeback");

    cpu_state_t cpu;
    cpu_init(&cpu);

    /* Caso 1: instruccion tipo R (add), destino = rd, dato = alu_result */
    decoded_t d_r = {0};
    d_r.ctrl.reg_write = 1;
    d_r.ctrl.reg_dst = 1;
    d_r.instr.rd = 10;
    mem_result_t mr_r = {0};
    mr_r.alu_result = 55;
    stage_writeback(&cpu, d_r, mr_r);
    TEST_ASSERT_EQ("R-type escribe alu_result en rd", cpu.regs[10], 55);

    /* Caso 2: lw, destino = rt, dato = mem_data */
    decoded_t d_lw = {0};
    d_lw.ctrl.reg_write = 1;
    d_lw.ctrl.reg_dst = 0;
    d_lw.ctrl.mem_to_reg = 1;
    d_lw.instr.rt = 12;
    mem_result_t mr_lw = {0};
    mr_lw.mem_data = 77;
    stage_writeback(&cpu, d_lw, mr_lw);
    TEST_ASSERT_EQ("lw escribe mem_data en rt", cpu.regs[12], 77);

    /* Caso 3: nunca se escribe en $zero */
    decoded_t d_zero = {0};
    d_zero.ctrl.reg_write = 1;
    d_zero.ctrl.reg_dst = 1;
    d_zero.instr.rd = 0;
    mem_result_t mr_zero = {0};
    mr_zero.alu_result = 123;
    stage_writeback(&cpu, d_zero, mr_zero);
    TEST_ASSERT_EQ("$zero se mantiene en 0 pase lo que pase", cpu.regs[0], 0);

    /* Caso 4: reg_write apagado (sw) no debe escribir nada */
    decoded_t d_sw = {0};
    d_sw.ctrl.reg_write = 0;
    d_sw.instr.rt = 15;
    mem_result_t mr_sw = {0};
    mr_sw.alu_result = 999;
    stage_writeback(&cpu, d_sw, mr_sw);
    TEST_ASSERT_EQ("reg_write apagado no modifica el registro", cpu.regs[15], 0);

    TEST_SUMMARY();
}
